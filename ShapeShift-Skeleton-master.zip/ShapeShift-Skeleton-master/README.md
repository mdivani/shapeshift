# ShapeShift-Skeleton

To Run: </br>
  git clone https://github.com/Shapeshift-Public/ShapeShift-Skeleton </br>
  cd ShapeShift-Skeleton </br>
  npm install </br>
  bower install </br>
  node dev-server.js </br>
  
  then go to localhost:3000 in browser
